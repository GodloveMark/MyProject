import { Component, OnInit } from '@angular/core';

@Component({
  templateUrl: './bio.component.html',
})
export class BioComponent { }
